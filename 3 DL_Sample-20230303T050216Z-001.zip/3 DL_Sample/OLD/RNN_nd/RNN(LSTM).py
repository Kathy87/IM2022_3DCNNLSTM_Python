import contextlib
import csv
import re
from datetime import date, datetime
from scipy.io import arff
import pandas as pd
import os
from keras.layers import LSTM
from sklearn.metrics import mean_squared_error
import math
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"  # if like me you do not have a lot of memory in your GPU
os.environ["CUDA_VISIBLE_DEVICES"] = ""  # then these two lines force keras to use your CPU
from keras.models import Sequential
from keras.layers import Dense
import numpy as np
from sklearn.preprocessing import MinMaxScaler
import fnmatch

path = "D:\\3.Project\Dataset\Data\ForTest"

def getDirectory(path):
    files = [n for n in fnmatch.filter(os.listdir(path), "*")]
    return files

def getName(path):
    files = [n for n in fnmatch.filter(os.listdir(path), "*.arff")]
    names = []
    for filename in files:
        x = re.findall("[A-Z0-9]+", filename)
        names.append(x[0])
    names = list(dict.fromkeys(names))
    return names

def load_data(base, pattern, number):
    pattern = pattern + "*"
    files = [n for n in fnmatch.filter(os.listdir(base), pattern)]
    X_train_ori = ""
    X_test_ori = ""
    found = bool(False)
    for i in files:
        trainNumber = "train_" + str(number) + ".arff"
        testNumber = "test_" + str(number) + ".arff"
        path = base + "\\" + i
        if trainNumber in i:
            dt_train = arff.loadarff(path)
            X_train_ori = pd.DataFrame(dt_train[0]).to_numpy()
        elif testNumber in i:
            dt_test = arff.loadarff(path)
            X_test_ori = pd.DataFrame(dt_test[0]).values[0]
            found = bool(True)
        if (found == bool(True)):
            break
    return X_train_ori, X_test_ori

def RNN(week,Xtrain, Xtest, lstm, epoch):
    X_train = Xtrain[:, 0:-1]
    Y_train = Xtrain[:,-1]
    print("Y_train shape:", Y_train.shape)

    X_test = Xtest[0:-1]
    X_test = X_test.reshape(1, 80)
    Y_test = Xtest[-1]
    Y_test = Y_test.reshape(1)
    print("Y_test shape:", Y_test.shape)

    print(X_test.shape)

    # normalize the dataset
    scaler_features = MinMaxScaler(feature_range=(0, 1))
    all_data_features = np.concatenate((X_train, X_test))
    print("all features:", all_data_features.shape)
    scaler_features = scaler_features.fit(all_data_features)
    X_train_scaled = scaler_features.transform(X_train)
    X_test = X_test.reshape(1, -1)
    X_test_scaled = scaler_features.transform(X_test)

    scaler_labels = MinMaxScaler(feature_range=(0, 1))
    all_data_labels = np.concatenate((Y_train, Y_test))
    all_data_labels = all_data_labels.reshape(-1, 1)
    print("all labels:", all_data_labels.shape)
    scaler_labels = scaler_labels.fit(all_data_labels)
    Y_train = Y_train.reshape(-1, 1)
    Y_train_scaled = scaler_labels.transform(Y_train)
    Y_test = Y_test.reshape(-1, 1)
    Y_test_scaled = scaler_labels.transform(Y_test)

    print(Y_train_scaled)
    print(Y_test_scaled)

    X_train_scaled = X_train_scaled.reshape(week, 1, 80)
    Y_train_scaled = Y_train_scaled.reshape(week, 1)

    X_test_scaled = X_test_scaled.reshape(1, 1, 80)
    Y_test_scaled = Y_test_scaled.reshape(1, 1)

    # create and fit the LSTM network
    model = Sequential()
    model.add(LSTM(lstm, batch_input_shape=(1, X_train_scaled.shape[1], X_train_scaled.shape[2])))
    # model.add(Dense(32, activation= 'relu'))
    model.add(Dense(1))
    model.compile(loss='mean_squared_error', optimizer='adam')
    model.fit(X_train_scaled, Y_train_scaled, epochs=epoch, batch_size=1, verbose=2)

    # make predictions
    # trainPredict = model.predict(X_train_scaled[0].reshape(1,1,80))
    trainPredict = model.predict(X_train_scaled)
    testPredict = model.predict(X_test_scaled)

    print("Train predictions shape:", trainPredict.shape)

    # invert predictions
    trainPredict = scaler_labels.inverse_transform(trainPredict)
    testPredict = scaler_labels.inverse_transform(testPredict)


    print("testPredicted: ", testPredict)
    print("trainPredicted", trainPredict)


    # APE
    X_score = APE(Y_train,trainPredict)
    Y_score = APE(Y_test,testPredict)

    return Y_train, Y_test, testPredict, trainPredict, X_score, Y_score

#APE
def APE(actual, predicted):
    if(actual[0]!=0):
        ape_value = abs((actual[0] - predicted[:, 0]) / actual[0])
    else:
        ape_value = None
    return ape_value

file = open("data_run_RNN.csv", "w")
with open("data_run_RNN.csv", mode='a') as data_run:
    data_writer = csv.writer(data_run, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)

    start_date = date.today()
    now = datetime.now()
    start_time = now.strftime("%H:%M:%S")
    data_writer.writerow([start_date,start_time])


    files = [n for n in fnmatch.filter(os.listdir(path), "*")]

    for i in files:
        file_path = path + "\\" + i
        lstm = 32
        epoch = 50
        if i == "4Weeks":
            data_writer.writerow(["4Weeks"])
            # data_writer.writerow(["Y_train", "trainPredict", "Y_test", "testPredict","X_score","Y_score"])
            names = getName(file_path)
            for name in names:
                X_APE,Y_APE = [],[]
                for i in range(1,154):
                    X_train_ori, X_test_ori = load_data(file_path, name, i)
                    Y_train, Y_test, testPredict, trainPredict,X_score,Y_score = RNN(4, X_train_ori, X_test_ori,lstm,epoch)

                    # APE
                    if X_score != None:
                        X_APE.append(X_score)
                    if(Y_score != None):
                        Y_APE.append(Y_score)

                    # data_writer.writerow([Y_train[0], trainPredict[:, 0],Y_test[0], testPredict[:,0],X_score,Y_score])

                # # APE
                trainScore = (sum(X_APE)/len(X_APE))*100
                testScore = (sum(Y_APE)/len(Y_APE))*100

                # print("len_X_APE",len(X_APE))
                # print("len_y_APE",len(Y_APE))

                data_writer.writerow(["%.2f train_MAPE %%" % (trainScore),"%.2f test_MAPE %%" % (testScore), lstm, epoch, name])
        else:
            data_writer.writerow(["12Weeks"])
            data_writer.writerow(["Y_train", "trainPredict", "Y_test", "testPredict","X_score","Y_score"])
            names = getName(file_path)
            for name in names:
                X_APE, Y_APE = [], []
                for i in range(1,146):
                    X_train_ori, X_test_ori = load_data(file_path, name, i)
                    Y_train, Y_test, testPredict, trainPredict, X_score, Y_score, = RNN(12, X_train_ori, X_test_ori,lstm,epoch)

                    # APE
                    if X_score != None:
                        X_APE.append(X_score)
                    if(Y_score != None):
                        Y_APE.append(Y_score)

                    # data_writer.writerow([Y_train[0], trainPredict[:, 0],Y_test[0], testPredict[:,0],X_score,Y_score])

                #APE
                trainScore = (sum(X_APE)/len(X_APE))*100
                testScore = (sum(Y_APE)/len(Y_APE))*100
                #
                # print(X_APE)
                # print("len_X_APE",len(X_APE))
                # print("len_y_APE",len(Y_APE))

                data_writer.writerow(["%.2f train_MAPE %%" % (trainScore),"%.2f test_MAPE %%" % (testScore), lstm, epoch, name])
    end_date = date.today()
    now1 = datetime.now()
    end_time = now1.strftime("%H:%M:%S")
    data_writer.writerow([end_date,end_time])