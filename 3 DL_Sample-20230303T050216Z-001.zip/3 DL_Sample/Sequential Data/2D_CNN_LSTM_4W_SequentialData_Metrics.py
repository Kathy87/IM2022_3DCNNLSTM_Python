import csv
import fnmatch
import os
import re
from datetime import date, datetime

from keras.models import Sequential
from keras.layers import Conv2D, Dense, MaxPool2D, ConvLSTM2D, Dropout
from keras.layers import Dense
from sklearn.preprocessing import MinMaxScaler
from scipy.io import arff
import pandas as pd
import numpy as np
from keras.layers import Flatten
from keras.layers import LSTM
from keras.layers.wrappers import TimeDistributed

path = "D:\\3.Project\\Dataset\\Data\\ForTest\\Merged"


def getDirectory(path):
    files = [n for n in fnmatch.filter(os.listdir(path), "*")]
    return files


def getName(path):
    files = [n for n in fnmatch.filter(os.listdir(path), "*.arff")]
    names = []
    for filename in files:
        x = re.findall("[A-Z0-9]+", filename)
        names.append(x[0] + "_" + x[1])
    names = list(dict.fromkeys(names))
    return names


def load_data(path, name):
    pa = path + "\\" + name + ".arff"
    dt_train = arff.loadarff(pa)
    dataset_ori = pd.DataFrame(dt_train[0]).to_numpy()
    return dataset_ori


def split_data(dataset_ori, number_of_weeks, train_Nth):
    n = 0
    X_train, Y_train, X_test, Y_test = [], [], [], []

    found = bool(False)
    for i in range(train_Nth, len(dataset_ori)):
        j = i + number_of_weeks
        if n < number_of_weeks:
            n += 1

            # Added 4 or 12 values to each row of data
            X_train_sequence_1 = dataset_ori[i:j]

            X_train_sequence_2 = []
            for a in range(0, number_of_weeks):
                Xt1 = X_train_sequence_1[a].reshape(-1)
                Xt2 = X_train_sequence_1[a, -1].reshape(-1)
                Xt = np.concatenate([Xt1, Xt2, Xt2, Xt2, Xt2])
                X_train_sequence_2.append(Xt)
            X_train_sequence_2 = np.array(X_train_sequence_2).reshape(-1)
            X_train.append(X_train_sequence_2)

            Y_train1 = dataset_ori[j, -1].reshape(-1)
            Y_train.append(Y_train1)

        elif n == number_of_weeks:
            n += 1
            X_test_sequence_2 = []
            X_test_sequence_1 = dataset_ori[i:j]
            for a in range(0, number_of_weeks):
                Xte1 = X_test_sequence_1[a].reshape(-1)
                Xte2 = X_test_sequence_1[a, -1].reshape(-1)
                Xte = np.concatenate([Xte1, Xte2, Xte2, Xte2, Xte2])
                X_test_sequence_2.append(Xte)
            X_test = np.array(X_test_sequence_2).reshape(-1)
            Y_test = dataset_ori[j, -1].reshape(-1)
            found = bool(True)
        if (found == bool(True)):
            break
    return X_train, Y_train, X_test, Y_test,


def CNN_LSTM(Xtrain, Ytrain, Xtest, Ytest, number_of_weeks):
    X_train = np.array(Xtrain)
    Y_train = np.array(Ytrain).reshape(-1)

    X_test = np.array(Xtest).reshape(1, 85 * number_of_weeks)
    Y_test = np.array(Ytest).reshape(-1)

    # normalize the dataset
    scaler_features = MinMaxScaler(feature_range=(0, 1))
    all_data_features = np.concatenate((X_train, X_test))
    print("all features:", all_data_features.shape)
    scaler_features = scaler_features.fit(all_data_features)
    X_train_scaled = scaler_features.transform(X_train)
    X_test = X_test.reshape(1, -1)
    X_test_scaled = scaler_features.transform(X_test)

    scaler_labels = MinMaxScaler(feature_range=(0, 1))
    all_data_labels = np.concatenate((Y_train, Y_test))
    all_data_labels = all_data_labels.reshape(-1, 1)
    print("all labels:", all_data_labels.shape)
    scaler_labels = scaler_labels.fit(all_data_labels)
    Y_train = Y_train.reshape(-1, 1)
    Y_train_scaled = scaler_labels.transform(Y_train)
    Y_test = Y_test.reshape(-1, 1)
    Y_test_scaled = scaler_labels.transform(Y_test)

    print('X_test_scaled.shape: ', X_test_scaled.shape)
    print(X_test_scaled)

    # convert to 2D
    X_train_scaled = X_train_scaled.reshape(number_of_weeks, number_of_weeks, 17, 5, 1)
    X_test_scaled = X_test_scaled.reshape(1, number_of_weeks, 17, 5, 1)

    # 2D_CNN
    model = Sequential()
    model.add(TimeDistributed(Conv2D(32, (2, 2), activation='relu', input_shape=(number_of_weeks, 17, 5, 1))))
    model.add(TimeDistributed(MaxPool2D(pool_size=(2, 2))))
    model.add(Dropout(0.7))
    model.add(TimeDistributed(Flatten()))
    model.add(LSTM(64, activation='relu'))
    model.add(Dropout(0.7))
    model.add(Dense(32, activation='relu'))
    model.add(Dropout(0.7))
    model.add(Dense(1, activation='sigmoid'))
    model.compile(optimizer='adam', loss='MeanSquaredError', metrics='MeanAbsolutePercentageError')
    model.fit(X_train_scaled, Y_train_scaled, batch_size=1, epochs=10)
    model.evaluate(X_test_scaled, Y_test_scaled)

    # make predictions
    # trainPredict = model.predict(X_train_scaled)
    testPredict = model.predict(X_test_scaled)

    # invert predictions
    # trainPredict = scaler_labels.inverse_transform(trainPredict)
    testPredict = scaler_labels.inverse_transform(testPredict)

    # APE
    # X_score = APE(Y_train, trainPredict)

    Y_score_MAPE, Y_score_MAE = relative_MAE(Y_test, testPredict)
    Y_score_MSE = relative_MSE(Y_test, testPredict)

    return Y_score_MAPE, Y_score_MAE, Y_score_MSE, Y_test, testPredict


# APE
def relative_MAE(actual, predicted):
    MAE_value = abs((actual[0] - predicted[:, 0]))
    if (actual[0] != 0):
        MAPE_value = MAE_value / actual[0]
    else:
        MAPE_value = None
    return MAPE_value, MAE_value


def relative_MSE(actual, predicted):
    rel_MSE_value = np.square(actual[0] - predicted[:, 0])
    return rel_MSE_value


def run_model(file_path, number_of_weeks):
    names = getName(file_path)
    data_writer.writerow(
        ["name of drugs", "number of weeks",
         "MAPE_2017", "MAPE_2018", "MAPE_2019", "2016-2019",
         "MAE_2017", "MAE_2018", "MAE_2019", "2016-2019",
         "MSE_2017", "MSE_2018", "MSE_2019", "2016-2019",
         "RMSE_2017", "RMSE_2018", "RMSE_2019", "2016-2019"])
    with open("all" + result, mode='a') as all_results:
        all_results = csv.writer(all_results, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
        all_results.writerow(["Name", "No.", "Actual", "Predicted"])
    for name in names:
        Y_MAPE, Y_MAPE_2017, Y_MAPE_2018, Y_MAPE_2019 = [], [], [], []
        Y_MAE, Y_MAE_2017, Y_MAE_2018, Y_MAE_2019 = [], [], [], []
        Y_MSE, Y_MSE_2017, Y_MSE_2018, Y_MSE_2019 = [], [], [], []

        dataset_ori = load_data(file_path, name)
        train_Nth = (len(dataset_ori) - (number_of_weeks * 2))

        for j in range(1, train_Nth):
            X_train, Y_train, X_test, Y_test = split_data(dataset_ori, number_of_weeks, j)
            Y_score_MAPE, Y_score_MAE, Y_score_MSE, Y_test, testPredict = CNN_LSTM(X_train, Y_train, X_test, Y_test,
                                                                                   number_of_weeks)

            all_results.writerow([name, j, Y_test, testPredict])
            ### MAPE score
            if Y_score_MAPE != None:
                if j in range(11, 64):
                    Y_MAPE_2017.append(Y_score_MAPE)
                elif j in range(64, 116):
                    Y_MAPE_2018.append(Y_score_MAPE)
                elif j >= 116:
                    Y_MAPE_2019.append(Y_score_MAPE)
                Y_MAPE.append(Y_score_MAPE)
            # data_writer.writerow([Y_test, testPredict])
            ### MAE, MSE score
            if j in range(11, 64):
                Y_MAE_2017.append(Y_score_MAE)
                Y_MSE_2017.append(Y_score_MSE)
                # Y_RMSE_2017.append(Y_score_RMSE)
            elif j in range(64, 116):
                Y_MAE_2018.append(Y_score_MAE)
                Y_MSE_2018.append(Y_score_MSE)
                # Y_RMSE_2018.append(Y_score_RMSE)
            elif j >= 116:
                Y_MAE_2019.append(Y_score_MAE)
                Y_MSE_2019.append(Y_score_MSE)
                # Y_RMSE_2019.append(Y_score_RMSE)

            Y_MAE.append(Y_score_MAE)
            Y_MSE.append(Y_score_MSE)
            # Y_RMSE.append(Y_score_RMSE)

        ### MAPE for each year
        MAPE_2017 = (sum(Y_MAPE_2017) / len(Y_MAPE_2017)) * 100
        MAPE_2018 = (sum(Y_MAPE_2018) / len(Y_MAPE_2018)) * 100
        MAPE_2019 = (sum(Y_MAPE_2019) / len(Y_MAPE_2019)) * 100
        MAPE_3years = (sum(Y_MAPE) / len(Y_MAPE)) * 100
        ### MAE for each year
        MAE_2017 = (sum(Y_MAE_2017) / len(Y_MAE_2017))
        MAE_2018 = (sum(Y_MAE_2018) / len(Y_MAE_2018))
        MAE_2019 = (sum(Y_MAE_2019) / len(Y_MAE_2019))
        MAE_3years = (sum(Y_MAE) / len(Y_MAE))
        ### MSE for each year
        MSE_2017 = (sum(Y_MSE_2017) / len(Y_MSE_2017))
        MSE_2018 = (sum(Y_MSE_2018) / len(Y_MSE_2018))
        MSE_2019 = (sum(Y_MSE_2019) / len(Y_MSE_2019))
        MSE_3years = (sum(Y_MSE) / len(Y_MSE))
        ### RMSE for each year
        RMSE_2017 = np.sqrt(MSE_2017)
        RMSE_2018 = np.sqrt(MSE_2018)
        RMSE_2019 = np.sqrt(MSE_2019)
        RMSE_3years = np.sqrt(MSE_3years)

        data_writer.writerow(
            [name, number_of_weeks, "%.2f" % MAPE_2017, "%.2f" % MAPE_2018, "%.2f" % MAPE_2019,
             "%.2f" % MAPE_3years, "%.2f" % MAE_2017, "%.2f" % MAE_2018, "%.2f" % MAE_2019,
             "%.2f" % MAE_3years, "%.2f" % MSE_2017, "%.2f" % MSE_2018, "%.2f" % MSE_2019,
             "%.2f" % MSE_3years, "%.2f" % RMSE_2017, "%.2f" % RMSE_2018, "%.2f" % RMSE_2019,
             "%.2f" % RMSE_3years])
        with open("temp" + result, mode='a') as TempFile:
            TempFile = csv.writer(TempFile, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            TempFile.writerow(
                [name, number_of_weeks, "%.2f" % MAPE_2017, "%.2f" % MAPE_2018, "%.2f" % MAPE_2019,
                 "%.2f" % MAPE_3years, "%.2f" % MAE_2017, "%.2f" % MAE_2018, "%.2f" % MAE_2019,
                 "%.2f" % MAE_3years, "%.2f" % MSE_2017, "%.2f" % MSE_2018, "%.2f" % MSE_2019,
                 "%.2f" % MSE_3years, "%.2f" % RMSE_2017, "%.2f" % RMSE_2018, "%.2f" % RMSE_2019,
                 "%.2f" % RMSE_3years])


# write to file
nameofresult = "2DCNNLSTM_4W_64_10_07_Test_full"
result = nameofresult + ".csv"
file = open(result, "w")
with open(result, mode='a') as data_run:
    data_writer = csv.writer(data_run, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
    start_date = date.today()
    now = datetime.now()
    start_time = now.strftime("%H:%M:%S")
    data_writer.writerow([start_date, start_time, nameofresult])

    # Start
    files = [n for n in fnmatch.filter(os.listdir(path), "*")]
    for i in files:
        file_path = path + "\\" + i
        if i == "4Weeks":
            run_model(file_path, 4)
        elif i == "12Weeks":
            run_model(file_path, 12)
