import csv

import pandas as pd

df_ori = pd.read_csv("D:\\3.Project\\Dataset\\Others\\allvalues\\3D_4W_1989_ori.csv", header= None)
df_new = pd.read_csv("D:\\3.Project\\Dataset\\Others\\allvalues\\3D_4W_1989_new.csv")

dt_ori = df_ori.to_numpy()
dt_new = df_new.to_numpy()

j = 1
a = 0
n = 0
for i in range(j, len(dt_ori)):
    if n >= 149:
        a += 1
        n = 0
    ori_ = dt_ori[i, 3]
    new_ = dt_new[n, a + 1]
    n += 1
    # with open("temp1919.csv", mode='a') as TempFile:
    #     TempFile = csv.writer(TempFile, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
    #     TempFile.writerow([ori_, new_])
    if ori_ != str(new_):
        print(("ori_ and new_", ori_, new_, i, a,n))
    else:
        print("PASSED")

