import fnmatch
import os
import re

from scipy.io import arff
import pandas as pd

path1 = "D:\Kathy2021\Data\FULL\\4Weeks"
path2 = "D:\Kathy2021\Data\ForTest\Merged\\4Weeks\\"

def getDirectory(path):
    files = [n for n in fnmatch.filter(os.listdir(path), "*")]
    return files

def getName(path):
    files = [n for n in fnmatch.filter(os.listdir(path), "*.arff")]
    names = []
    for filename in files:
        x = re.findall("[A-Z0-9]+", filename)
        names.append(x[0]+"_")
    names = list(dict.fromkeys(names))
    return names

def load_data(base, pattern, number):
    pattern = pattern + "*"
    files = [n for n in fnmatch.filter(os.listdir(base), pattern)]
    X_train_ori, X_test_ori = "",""
    found = bool(False)
    for i in files:
        trainNumber = "train_" + str(number) + ".arff"
        # testNumber = "test_" + str(number) + ".arff"

        path = base + "\\" + i
        dt_train = arff.loadarff(path)
        if trainNumber in i:
            X_train_ori = pd.DataFrame(dt_train[0]).to_numpy()
        # elif "test_153" in testNumber:
        #     X_test_ori = pd.DataFrame(dt_train[0]).to_numpy()

    return X_train_ori

names = getName(path1)
count = 0
for name in names:
    print("Name of drug", name)
    count += 1
    path_merged = path2 +"\\"+name+str(count)+".arff"
    dt_train_merged = arff.loadarff(path_merged)
    X_train_merged = pd.DataFrame(dt_train_merged[0]).to_numpy()
    for i in range(1,154):
        X_train_ori = load_data(path1,name,i)
        # X_test_ori = load_data(path1,name,i)

        if (i != 1) :
            #X_train_ori at row 3 and column 80 (final)
            #X_train_merged at row i+2 = 2+2 = 4 (from 2, because don't need to check row 1)
            X_train = X_train_ori[2,-1]
            if (X_train_merged[i+2,-1]==X_train):
                print("Result Passed", i)
            else:
                print("Result Faileddddddddd", i)
        if (i == 153):
            X_train = X_train_ori[3,-1]
            if (X_train_merged[i+3,-1]==X_train):
                print("TEST FILE Passed", i)
            else:
                print("TEST FILE Faileddddddddd", i)
        #     if (X_train_merged[i+3,-1]==X_test):
        #         print("Result TEST FILE Passed", i)
        #     else:
        #         print("Result TEST FILE Faileddddddddd", i)
        # X_test = X_train_ori[0,-1]
        # if (X_train_merged[i-1,-1]==X_test):
        #     print("Result Passed", i)
        # else:
            # print("Result Faileddddddddd", i)

