import pandas as pd

from_ori_path = "D:\\3.Project\\Dataset\\Others\\3D_4W_1989\\3D_4W_1989_ori.csv"
to_new_path = "D:\\3.Project\\Dataset\\Others\\3D_4W_1989\\3D_4W_1989_new.csv"

df_ori = pd.read_csv(from_ori_path, header = None)
dt_arr = df_ori.to_numpy()
pre_values = []
i = 1
for j in range(0, 265):
    step = i + 149
    pre_values.append(dt_arr[i:step, -1])
    i = step
pre_values = pd.DataFrame(pre_values)

pre_values = pd.DataFrame.transpose(pre_values)
pre_values.to_csv(to_new_path)


