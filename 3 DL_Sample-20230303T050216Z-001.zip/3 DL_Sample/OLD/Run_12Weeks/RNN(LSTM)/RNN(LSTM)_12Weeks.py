import contextlib
import time
import csv
import re
from datetime import date, datetime
from scipy.io import arff
import pandas as pd
import os
from keras.layers import LSTM, Dropout
from sklearn.metrics import mean_squared_error
import math

os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"  # if like me you do not have a lot of memory in your GPU
os.environ["CUDA_VISIBLE_DEVICES"] = ""  # then these two lines force keras to use your CPU
from keras.models import Sequential
from keras.layers import Dense
import numpy as np
from sklearn.preprocessing import MinMaxScaler
import fnmatch

path = "D:\Kathy2021\Data\Merged"


def getDirectory(path):
    files = [n for n in fnmatch.filter(os.listdir(path), "*")]
    return files


def getName(path):
    files = [n for n in fnmatch.filter(os.listdir(path), "*.arff")]
    names = []
    for filename in files:
        x = re.findall("[A-Z0-9]+", filename)
        names.append(x[0] + "_" + x[1])
    names = list(dict.fromkeys(names))
    return names


def load_data(path,name):

    pa = path + "\\" + name + ".arff"
    dt_train = arff.loadarff(pa)
    dataset_ori = pd.DataFrame(dt_train[0]).to_numpy()
    return dataset_ori


def split_data(dataset_ori,number_of_weeks,train_Nth):
    n = 0
    X_train, Y_train, X_test, Y_test= [], [], [], []
    found = bool(False)
    for i in range(train_Nth, len(dataset_ori)):
        j = i + number_of_weeks
        if (n < number_of_weeks):
            # i = i+1
            n += 1
            X_train1 = dataset_ori[i:j].reshape(-1)
            Y_train1 = dataset_ori[j, -1].reshape(-1)
            X_train.append(X_train1)
            Y_train.append(Y_train1)

        elif (n == number_of_weeks):
            n += 1
            X_test = dataset_ori[i:j].reshape(1, 81*number_of_weeks)
            Y_test = dataset_ori[j, -1].reshape(-1)
            found = bool(True)
        if (found == bool(True)):
            break

    return X_train, Y_train, X_test, Y_test


def RNN(X_train, Y_train,X_test,Y_test, number_of_weeks, lstm_para, epoch_para):

    X_train = np. array(X_train)
    Y_train = np. array(Y_train).reshape(-1)

    # normalize the dataset
    scaler_features = MinMaxScaler(feature_range=(0, 1))
    all_data_features = np.concatenate((X_train, X_test))
    print("all features:", all_data_features.shape)
    scaler_features = scaler_features.fit(all_data_features)
    X_train_scaled = scaler_features.transform(X_train)
    X_test = X_test.reshape(1, -1)
    X_test_scaled = scaler_features.transform(X_test)

    scaler_labels = MinMaxScaler(feature_range=(0, 1))
    all_data_labels = np.concatenate((Y_train, Y_test))
    all_data_labels = all_data_labels.reshape(-1, 1)
    print("all labels:", all_data_labels.shape)
    scaler_labels = scaler_labels.fit(all_data_labels)
    Y_train = Y_train.reshape(-1, 1)
    Y_train_scaled = scaler_labels.transform(Y_train)
    Y_test = Y_test.reshape(-1, 1)
    Y_test_scaled = scaler_labels.transform(Y_test)

    print(Y_train_scaled)
    print(Y_test_scaled)

    X_train_scaled = X_train_scaled.reshape(number_of_weeks, number_of_weeks, 81)
    Y_train_scaled = Y_train_scaled.reshape(number_of_weeks, 1)
    X_train_scaled = np.array(X_train_scaled)


    X_test_scaled = X_test_scaled.reshape(1, number_of_weeks, 81)
    Y_test_scaled = Y_test_scaled.reshape(1, 1)

    # create and fit the LSTM network
    model = Sequential()
    model.add(LSTM(lstm_para, activation= 'relu',batch_input_shape=(1, X_train_scaled.shape[1], X_train_scaled.shape[2])))
    model.add(Dropout(0.7))
    model.add(Dense(64, activation= 'relu'))
    model.add(Dropout(0.7))
    model.add(Dense(32, activation= 'relu'))
    model.add(Dropout(0.7))
    model.add(Dense(1, activation= 'sigmoid'))
    model.compile(loss='mean_squared_error', optimizer='adam')
    model.fit(X_train_scaled, Y_train_scaled, epochs=epoch_para, batch_size=1, verbose=2)

    # make predictions
    # trainPredict = model.predict(X_train_scaled)
    testPredict = model.predict(X_test_scaled)


    # invert predictions
    # trainPredict = scaler_labels.inverse_transform(trainPredict)
    testPredict = scaler_labels.inverse_transform(testPredict)

 
    # APE
    # X_score = APE(Y_train, trainPredict)
    X_score = 0
    Y_score = APE(Y_test, testPredict)

    return  X_score, Y_score

# APE
def APE(actual, predicted):
    if (actual[0] != 0):
        ape_value = abs((actual[0] - predicted[:, 0]) / actual[0])
    else:
        ape_value = None
    return ape_value

nameofresult = "RNN(LSTM)_12Weeks_LSTM128_Epoch25_0.7_noaddDense64"
result = nameofresult+".csv"
file = open(result, "w")
with open(result, mode='a') as data_run:
    data_writer = csv.writer(data_run, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)

    start_date = date.today()
    now = datetime.now()
    start_time = now.strftime("%H:%M:%S")
    start = time.time()
    data_writer.writerow([start_date, start_time, nameofresult])

    files = [n for n in fnmatch.filter(os.listdir(path), "*")]

    for i in files:
        file_path = path + "\\" + i
        lstm_para = 128
        epoch_para = 25
        if i == "4Weeks":
            print("NO run")
            # data_writer.writerow(["name of drugs", "number of weeks", "MAPE_2017","MAPE_2018","MAPE_2019","2016-2019"])
            # names = getName(file_path)
            # number_of_weeks = 4
            #
            # for name in names:
            #     Y_APE, Y_APE_2017, Y_APE_2018, Y_APE_2019 = [], [], [], []
            #     dataset_ori = load_data(file_path, name)
            #     train_Nth = (len(dataset_ori) -(number_of_weeks *2))
            #
            #     for j in range(1, train_Nth):
            #         X_train, Y_train,X_test,Y_test = split_data(dataset_ori,number_of_weeks, j)
            #
            #         X_score, Y_score = RNN(X_train, Y_train, X_test, Y_test, number_of_weeks, lstm_para, epoch_para)
            #
            #
            #         if(Y_score != None):
            #             if j in range(12,65):
            #                 Y_APE_2017.append(Y_score)
            #             elif j in range(65,117):
            #                 Y_APE_2018.append(Y_score)
            #             elif (j>=117):
            #                 Y_APE_2019.append(Y_score)
            #
            #             Y_APE.append(Y_score)
            #
            #     # MAPE
            #     testScore_2017 = (sum(Y_APE_2017)/len(Y_APE_2017))*100
            #     testScore_2018 = (sum(Y_APE_2018)/len(Y_APE_2018))*100
            #     testScore_2019 = (sum(Y_APE_2019)/len(Y_APE_2019))*100
            #     testScore = (sum(Y_APE)/len(Y_APE))*100
            #
            #     data_writer.writerow([name, "4Weeks", "%.2f" % (testScore_2017), "%.2f" % (testScore_2018),"%.2f" % (testScore_2019),"%.2f" % (testScore)])
            #     with open("temp_LSTM_64_30_0.7.csv", mode='a') as TempFile:
            #         TempFile = csv.writer(TempFile, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            #         TempFile.writerow([name, "4Weeks", "%.2f" % (testScore_2017), "%.2f" % (testScore_2018),"%.2f" % (testScore_2019),"%.2f" % (testScore)])
        elif i =="12Weeks":
            data_writer.writerow(["name of drugs", "number of weeks", "MAPE_2017","MAPE_2018","MAPE_2019","2016-2019"])
            names = getName(file_path)
            number_of_weeks = 12

            for name in names:
                Y_APE, Y_APE_2017, Y_APE_2018, Y_APE_2019 = [], [], [], []
                dataset_ori = load_data(file_path, name)
                train_Nth = (len(dataset_ori) -(number_of_weeks *2))

                for j in range(1, train_Nth):
                    X_train, Y_train,X_test,Y_test = split_data(dataset_ori,number_of_weeks, j)

                    X_score, Y_score = RNN(X_train, Y_train, X_test, Y_test, number_of_weeks, lstm_para, epoch_para)


                    if(Y_score != None):
                        if j in range(12,65):
                            Y_APE_2017.append(Y_score)
                        elif j in range(65,117):
                            Y_APE_2018.append(Y_score)
                        elif (j>=117):
                            Y_APE_2019.append(Y_score)

                        Y_APE.append(Y_score)

                # MAPE
                testScore_2017 = (sum(Y_APE_2017)/len(Y_APE_2017))*100
                testScore_2018 = (sum(Y_APE_2018)/len(Y_APE_2018))*100
                testScore_2019 = (sum(Y_APE_2019)/len(Y_APE_2019))*100
                testScore = (sum(Y_APE)/len(Y_APE))*100

                data_writer.writerow([name, "12Weeks", "%.2f" % (testScore_2017), "%.2f" % (testScore_2018),"%.2f" % (testScore_2019),"%.2f" % (testScore)])
                with open("temp_"+result, mode='a') as TempFile:
                    TempFile = csv.writer(TempFile, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
                    TempFile.writerow([name, "12Weeks", "%.2f" % (testScore_2017), "%.2f" % (testScore_2018),"%.2f" % (testScore_2019),"%.2f" % (testScore)])
    end_date = date.today()
    now1 = datetime.now()
    end_time = now1.strftime("%H:%M:%S")

    end = time.time()
    total = end-start
    data_writer.writerow([end_date,end_time, total])
