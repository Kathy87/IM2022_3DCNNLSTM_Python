import csv
import fnmatch
import os
import re
from datetime import date, datetime

from keras.models import Sequential
from keras.layers import Conv2D, Dense, MaxPool2D, ConvLSTM2D, Dropout
from keras.layers import Dense
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import MinMaxScaler
import math
from scipy.io import arff
import pandas as pd
import numpy as np
from tensorflow.python.keras.backend import relu, sigmoid
from keras.layers import Flatten
from keras.layers import LSTM
from keras.layers.wrappers import TimeDistributed
import tensorflow as tf

# path = "D:\\3.Project\Dataset\Data\FULL"
path = "D:\\Kathy2021\\Data\\FULL"
def getDirectory(path):
    files = [n for n in fnmatch.filter(os.listdir(path), "*")]
    return files

def getName(path):
    files = [n for n in fnmatch.filter(os.listdir(path), "*.arff")]
    names = []
    for filename in files:
        x = re.findall("[A-Z0-9]+", filename)
        names.append(x[0])
    names = list(dict.fromkeys(names))
    return names

def load_data(base, pattern, number):
    pattern = pattern + "*"
    files = [n for n in fnmatch.filter(os.listdir(base), pattern)]
    X_train_ori = ""
    X_test_ori = ""
    found = bool(False)
    for i in files:
        trainNumber = "train_" + str(number) + ".arff"
        testNumber = "test_" + str(number) + ".arff"
        path = base + "\\" + i
        if trainNumber in i:
            dt_train = arff.loadarff(path)
            X_train_ori = pd.DataFrame(dt_train[0]).to_numpy()
        elif testNumber in i:
            dt_test = arff.loadarff(path)
            X_test_ori = pd.DataFrame(dt_test[0]).values[0]
            found = bool(True)
        if (found == bool(True)):
            break
    return X_train_ori, X_test_ori

def CNN_LSTM(week,Xtrain, Xtest, n_lstms, n_epochs, dropout):
    X_train = Xtrain[:, 0:-1]
    Y_train = Xtrain[:, -1]
    print("Y_train shape:", Y_train.shape)

    X_test = Xtest[0:-1]
    X_test = X_test.reshape(1, 80)
    Y_test = Xtest[-1]
    Y_test = Y_test.reshape(1)
    print("Y_test shape:", Y_test.shape)

    # normalize the dataset
    scaler_features = MinMaxScaler(feature_range=(0, 1))
    all_data_features = np.concatenate((X_train, X_test))
    print("all features:", all_data_features.shape)
    scaler_features = scaler_features.fit(all_data_features)
    X_train_scaled = scaler_features.transform(X_train)
    X_test = X_test.reshape(1, -1)
    X_test_scaled = scaler_features.transform(X_test)

    scaler_labels = MinMaxScaler(feature_range=(0, 1))
    all_data_labels = np.concatenate((Y_train, Y_test))
    all_data_labels = all_data_labels.reshape(-1, 1)
    print("all labels:", all_data_labels.shape)
    scaler_labels = scaler_labels.fit(all_data_labels)
    Y_train = Y_train.reshape(-1, 1)
    Y_train_scaled = scaler_labels.transform(Y_train)
    Y_test = Y_test.reshape(-1, 1)
    Y_test_scaled = scaler_labels.transform(Y_test)


    print('X_test_scaled.shape: ', X_test_scaled.shape)
    print(X_test_scaled)

    #convert to 2D
    X_train_scaled = X_train_scaled.reshape(week, 1, 16, 5, 1)
    X_test_scaled = X_test_scaled.reshape(1, 1, 16, 5, 1)


    #2D_CNN
    model = Sequential()
    model.add(TimeDistributed(Conv2D(32, (3,3), input_shape=(1, 16, 5, 1))))
    model.add(TimeDistributed(MaxPool2D(pool_size=(2,2))))
    model.add(Dropout(dropout))
    model.add(TimeDistributed(Flatten()))
    model.add(LSTM(n_lstms, activation='relu'))
    model.add(Dropout(dropout))
    model.add(Dense(64, activation='relu'))
    model.add(Dropout(dropout))
    model.add(Dense(32, activation='relu'))
    model.add(Dropout(dropout))
    model.add(Dense(1, activation='sigmoid'))

    model.compile(optimizer='adam', loss='MeanSquaredError', metrics='MeanAbsolutePercentageError')
    model.fit(X_train_scaled, Y_train_scaled, batch_size=1, epochs=n_epochs)
    model.evaluate(X_test_scaled, Y_test_scaled)

    # make predictions
    trainPredict = model.predict(X_train_scaled)
    testPredict = model.predict(X_test_scaled)

    # invert predictions
    trainPredict = scaler_labels.inverse_transform(trainPredict)
    testPredict = scaler_labels.inverse_transform(testPredict)

    # APE
    # X_score = APE(Y_train, trainPredict)
    X_score = 0
    Y_score = APE(Y_test, testPredict)

    return Y_train, Y_test, testPredict, trainPredict, X_score, Y_score

#APE
def APE(actual, predicted):
    if(actual[0]!=0 ):
        # if (predicted.shape[0] == 1):
        ape_value = abs((actual[0] - predicted[:, 0]) / actual[0])
        # else:
        #     ape_value = abs((actual[0] - np.mean(predicted[:, 0])) / actual[0])
    else:
        ape_value = None
    return ape_value

#write to file
nameofresult = "2DCNNLSTM_12W_LSTM64_40__Kernel32_33_Added"
result = nameofresult + ".csv"
file = open(result, "w")
with open(result, mode='a') as data_run:
    data_writer = csv.writer(data_run, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
    start_date = date.today()
    now = datetime.now()
    start_time = now.strftime("%H:%M:%S")
    data_writer.writerow([start_date,start_time, nameofresult])

#Start
    files = [n for n in fnmatch.filter(os.listdir(path), "*")]
    for i in files:
        n_lstms = 64
        n_epochs = 40
        dropout = 0.7


        file_path = path + "\\" + i
        if i == "4Weeks":
            print("NO RUN")
            # names = getName(file_path)
            # data_writer.writerow(["name of drugs", "number of weeks", "MAPE_2017","MAPE_2018","MAPE_2019"])
            # for name in names:
            #     Y_APE, Y_APE_2017, Y_APE_2018, Y_APE_2019 = [], [], [], []
            #     for j in range(1, 154):
            #         X_train_ori, X_test_ori = load_data(file_path, name, j)
            #         Y_train, Y_test, testPredict, trainPredict, X_score, Y_score = CNN_LSTM(4, X_train_ori, X_test_ori, n_lstms,n_epochs,dropout)
            #
            #         if(Y_score != None):
            #             if j in range (11,64):
            #                 Y_APE_2017.append(Y_score)
            #             elif j in range(64,116):
            #                 Y_APE_2018.append(Y_score)
            #             elif (j>=116):
            #                 Y_APE_2019.append(Y_score)
            #
            #             Y_APE.append(Y_score)
            #
            #     # # APE
            #     testScore_2017 = (sum(Y_APE_2017)/len(Y_APE_2017))*100
            #     testScore_2018 = (sum(Y_APE_2018)/len(Y_APE_2018))*100
            #     testScore_2019 = (sum(Y_APE_2019)/len(Y_APE_2019))*100
            #     testScore = (sum(Y_APE)/len(Y_APE))*100
            #
            #     data_writer.writerow([name, "4Weeks", "%.2f" % (testScore_2017), "%.2f" % (testScore_2018),"%.2f" % (testScore_2019),"%.2f" % (testScore)])
            #     with open("temp_2DCNNLSTM_64_25_07_exclude_1Dropout.csv", mode='a') as TempFile:
            #         TempFile = csv.writer(TempFile, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            #         TempFile.writerow([name, "4Weeks", "%.2f" % (testScore_2017), "%.2f" % (testScore_2018),"%.2f" % (testScore_2019),"%.2f" % (testScore)])
        elif i == "12Weeks":
            names = getName(file_path)
            data_writer.writerow(["name of drugs", "number of weeks", "MAPE_2017", "MAPE_2018", "MAPE_2019"])
            for name in names:
                Y_APE, Y_APE_2017, Y_APE_2018, Y_APE_2019 = [], [], [], []
                for j in range(1, 146):
                    X_train_ori, X_test_ori = load_data(file_path, name, j)
                    Y_train, Y_test, testPredict, trainPredict, X_score, Y_score = CNN_LSTM(12, X_train_ori, X_test_ori,
                                                                                            n_lstms, n_epochs, dropout)

                    if (Y_score != None):
                        if j in range(11, 64):
                            Y_APE_2017.append(Y_score)
                        elif j in range(64, 116):
                            Y_APE_2018.append(Y_score)
                        elif (j >= 116):
                            Y_APE_2019.append(Y_score)

                        Y_APE.append(Y_score)

                # # APE
                testScore_2017 = (sum(Y_APE_2017) / len(Y_APE_2017)) * 100
                testScore_2018 = (sum(Y_APE_2018) / len(Y_APE_2018)) * 100
                testScore_2019 = (sum(Y_APE_2019) / len(Y_APE_2019)) * 100
                testScore = (sum(Y_APE) / len(Y_APE)) * 100

                data_writer.writerow(
                    [name, "12Weeks", "%.2f" % (testScore_2017), "%.2f" % (testScore_2018), "%.2f" % (testScore_2019),
                     "%.2f" % (testScore)])
                with open("temp_"+result, mode='a') as TempFile:
                    TempFile = csv.writer(TempFile, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
                    TempFile.writerow([name, "12Weeks", "%.2f" % (testScore_2017), "%.2f" % (testScore_2018),
                                       "%.2f" % (testScore_2019), "%.2f" % (testScore)])

    end_date = date.today()

    now1 = datetime.now()
    end_time = now1.strftime("%H:%M:%S")
    data_writer.writerow([end_date,end_time])
