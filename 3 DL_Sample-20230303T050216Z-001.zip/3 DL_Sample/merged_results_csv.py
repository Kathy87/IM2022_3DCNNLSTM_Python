import csv
import re
import os

import fnmatch
from datetime import date, datetime

path_1 = "D:\Kathy2021\SEPTEMBER_0000000000000000000\\3D_SD\\123\\3D_SD_64_90_P1.csv"
path_2 = "D:\Kathy2021\SEPTEMBER_0000000000000000000\\3D_SD\\123\\3D_SD_64_90_P2.csv"
##3DCNNLSTM_SD_12w_64_90_Con3v6432_LXSep_1_16
path_final = "D:\Kathy2021\SEPTEMBER_0000000000000000000\\3D_SD\\123\\"


nameofresult = "3D_SD_64_90_Final"
result = nameofresult + ".csv"
file = open(result, "w")
with open(result, mode='a') as data_run:
    data_writer = csv.writer(data_run, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)

    start_date = date.today()
    now = datetime.now()
    start_time = now.strftime("%H:%M:%S")
    data_writer.writerow([start_date, start_time, nameofresult])
    data_writer.writerow(
        ["name of drugs", "number of weeks", "MAPE_2017", "MAPE_2018", "MAPE_2019", "2016-2019"])
