from keras.layers import LSTM, Dense, Embedding
from keras import Model
from sklearn.multiclass import OutputCodeClassifier
from sklearn.svm import SVC
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from scipy.io import arff
from keras import Input
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_absolute_percentage_error
from sklearn import preprocessing
from sklearn.preprocessing import LabelEncoder
import csv
from sklearn.preprocessing import OneHotEncoder
from numpy import argmax
from libsvm.svmutil import svm_read_problem, svm_problem, svm_train, svm_save_model, svm_parameter, svm_predict

def get_model(timestep, dim):
    x = Input(shape=(timestep, dim))
    z, sh, sc = LSTM(units=128, return_state=True)(x)
    z = Dense(6, activation='softmax')(z)

    model1 = Model(inputs=[x],outputs=[z])
    model2 = Model(inputs=[x],outputs=[z,sh,sc])
    model1.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    return model1, model2


data_original = pd.read_csv('Istanbul_Weather_3.csv', usecols=[1, 2, 3, 8, 9, 10, 11])
Istanbul_Weather = data_original.iloc[::-1]
# print(Istanbul_Weather['Condition'])


condition = Istanbul_Weather['Condition']
# print(condition)

# integer encode
label_encoder = LabelEncoder()
integer_encoded = label_encoder.fit_transform(condition)
# print(integer_encoded)

# binary encode
onehot_encoder = OneHotEncoder(sparse=False)
integer_encoded = integer_encoded.reshape(len(integer_encoded), 1)
condition_encoded = onehot_encoder.fit_transform(integer_encoded)
# print(Condition_encoded)
# condition_nemaes = onehot_encoder.get_feature_names()
# print(condition_nemaes)

# invert first example
inverted = label_encoder.inverse_transform([argmax(condition_encoded[0, :])])
# print(inverted)

Istanbul_Weather = Istanbul_Weather.to_numpy()

# normalize the features
scaler_features = MinMaxScaler(feature_range=(0, 1))
scaler_features = scaler_features.fit(Istanbul_Weather[:, 0:6])
features = scaler_features.transform(Istanbul_Weather[:, 0:6])



def train_data(Istanbul_Weather, train_days=5):
    x_train_original, x_test_original, y_train_original, y_test_original = train_test_split(features[:,0:6], condition_encoded[:,]
                                                                                            , test_size=0.3, random_state=0, shuffle=False)
    x_train_split, y_train_split, x_test_split, y_test_split = [], [], [], []

    for i in range(x_train_original.shape[0]-train_days):
        x_train_split.append(np.array(x_train_original[i:i+5, 0:6]))
        y_train_split.append(np.array(y_train_original[i+5]))

    for j in range(x_test_original.shape[0]-train_days):
        x_test_split.append(np.array(x_test_original[j:j+5, 0:6]))
        y_test_split.append(np.array(y_test_original[j+5]))
    return x_train_split, y_train_split, x_test_split, y_test_split

x_train_split, y_train_split, x_test_split, y_test_split = train_data(Istanbul_Weather, train_days=5)


x_train = np.asarray(x_train_split).reshape(2710, 5, 6)
y_train = np.asarray(y_train_split).reshape(2710, 6)
x_test = np.asarray(x_test_split).reshape(1159, 5, 6)
y_test = np.asarray(y_test_split).reshape(1159, 6)



# x_train = np.asarray(x_train_reshape).astype('float32')
# y_train = np.asarray(y_train_reshape).astype('float32')
# x_test = np.asarray(x_test_reshape).astype('float32')
# y_test = np.asarray(y_test_reshape).astype('float32')
# print(y_train)

ResultFile = open('Results.txt', 'w')

model1, model2 = get_model(5, 6)
model1.fit(x_train, y_train, epochs=100, verbose=2)
z, sh, sc = model2.predict(x_train)
z_test, sh_test, sc_test = model2.predict(x_test)
# y_predict = model1.predict(x_test)
accuracy = model1.evaluate(x_test, y_test)

print('LSTM accuracy: {}'.format(accuracy[1]))
ResultFile.write('LSTM: ' + str(accuracy[1]) + '\n')
# print('y_train:', y_train)
# print('y_test:', y_test)
# print(sh[0])


y_train = np.argmax(y_train, axis=1)
y_test = np.argmax(y_test, axis=1)

# SVM
x_train = np.asarray(x_train).reshape(2710, 30)
y_train = np.asarray(y_train).reshape(2710)
x_test = np.asarray(x_test).reshape(1159, 30)
y_test = np.asarray(y_test).reshape(1159)

# for CValueExp in range(-5, 16, 2):
#     for GammaExp in range(-15, 4, 2):
#         CValue = 2**CValueExp
#         Gamma = 2**GammaExp

# normalize
scaler_features = MinMaxScaler(feature_range=(0, 1))
all_sh = np.concatenate((sh, sh_test))
scaler_features = scaler_features.fit(all_sh)
sh_train_scaled = scaler_features.transform(sh)
sh_test_scaled = scaler_features.transform(sh_test)

# LSTM+SVM
for CValueExp in range(-15, 25, 2):
    for GammaExp in range(-25, 12, 2):
        CValue = 2**CValueExp
        Gamma = 2**GammaExp
        param = svm_parameter('-s 0 -t 2 -c ' + str(CValue) + ' -g ' + str(Gamma) + ' -b 1')
        prob = svm_problem(y_train, sh_train_scaled)
        model = svm_train(prob, param)
        p_label, p_acc, p_val = svm_predict(y_test, sh_test_scaled, model)
        ResultFile.write('C: ' + str(CValue) + ', gamma: ' + str(Gamma) + ', accuracy: ' + str(p_acc[0]) + '\n')
# ResultFile.close()

# SVM
for CValueExp in range(-15, 25, 2):
    for GammaExp in range(-25, 12, 2):
        CValue = 2**CValueExp
        Gamma = 2**GammaExp
        param = svm_parameter('-s 0 -t 2 -c ' + str(CValue) + ' -g ' + str(Gamma) + ' -b 1')
        prob = svm_problem(y_train, x_train)
        model = svm_train(prob, param)
        p_label, p_acc, p_val = svm_predict(y_test, x_test, model)
        ResultFile.write('C: ' + str(CValue) + ', gamma: ' + str(Gamma) + ', accuracy: ' + str(p_acc[0]) + '\n')
ResultFile.close()

# prob = svm_problem(y_train, sh_train_scaled)
# for CValueExp in range(-15, 25, 2):
#     for GammaExp in range(-25, 12, 2):
#         CValue = 2**CValueExp
#         Gamma = 2**GammaExp
#         param = svm_parameter('-s 0 -t 2 -c ' + str(CValue) + ' -g ' + str(Gamma) + ' -b 1')
#         model = svm_train(prob, param)
#         p_label, p_acc, p_val = svm_predict(y_test, sh_test_scaled, model)
#
#         ResultFile.write('C: ' + str(CValue) + ', gamma: ' + str(Gamma) + ', accuracy: ' + str(p_acc[0]) + '\n')
# ResultFile.close()
