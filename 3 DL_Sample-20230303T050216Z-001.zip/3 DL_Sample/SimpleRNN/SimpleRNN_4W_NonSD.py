import contextlib
import csv
import re
from datetime import date, datetime
from random import randint

from keras import Input
from scipy.io import arff
import pandas as pd
import os
from keras.layers import LSTM, SimpleRNN

from tensorflow.python.keras.layers import Dropout

os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"  # if like me you do not have a lot of memory in your GPU
os.environ["CUDA_VISIBLE_DEVICES"] = ""  # then these two lines force keras to use your CPU
from keras.models import Sequential
from keras.layers import Dense
import numpy as np
from sklearn.preprocessing import MinMaxScaler
import fnmatch

path = "D:\Kathy2021\Data\FULL"

def getDirectory(path):
    files = [n for n in fnmatch.filter(os.listdir(path), "*")]
    return files

def getName(path):
    files = [n for n in fnmatch.filter(os.listdir(path), "*.arff")]
    names = []
    for filename in files:
        x = re.findall("[A-Z0-9]+", filename)
        names.append(x[0])
    names = list(dict.fromkeys(names))
    return names

def load_data(base, pattern, number):
    pattern = pattern + "*"
    files = [n for n in fnmatch.filter(os.listdir(base), pattern)]
    X_train_ori = ""
    X_test_ori = ""
    found = bool(False)
    for i in files:
        trainNumber = "train_" + str(number) + ".arff"
        testNumber = "test_" + str(number) + ".arff"
        path = base + "\\" + i
        if trainNumber in i:
            dt_train = arff.loadarff(path)
            X_train_ori = pd.DataFrame(dt_train[0]).to_numpy()
        elif testNumber in i:
            dt_test = arff.loadarff(path)
            X_test_ori = pd.DataFrame(dt_test[0]).values[0]
            found = bool(True)
        if (found == bool(True)):
            break
    return X_train_ori, X_test_ori

def Simple_RNN(week,Xtrain, Xtest, lstm_para, epoch_para):
    X_train = Xtrain[:, 0:-1]
    Y_train = Xtrain[:,-1]
    # print("Y_train shape:", Y_train.shape)

    X_test = Xtest[0:-1]
    X_test = X_test.reshape(1, 80)
    Y_test = Xtest[-1]
    Y_test = Y_test.reshape(1)

    # normalize the dataset
    scaler_features = MinMaxScaler(feature_range=(0, 1))
    all_data_features = np.concatenate((X_train, X_test))
    # print("all features:", all_data_features.shape)
    scaler_features = scaler_features.fit(all_data_features)
    X_train_scaled = scaler_features.transform(X_train)
    X_test = X_test.reshape(1, -1)
    X_test_scaled = scaler_features.transform(X_test)

    scaler_labels = MinMaxScaler(feature_range=(0, 1))
    all_data_labels = np.concatenate((Y_train, Y_test))
    all_data_labels = all_data_labels.reshape(-1, 1)
    # print("all labels:", all_data_labels.shape)
    scaler_labels = scaler_labels.fit(all_data_labels)
    Y_train = Y_train.reshape(-1, 1)
    Y_train_scaled = scaler_labels.transform(Y_train)
    Y_test = Y_test.reshape(-1, 1)
    Y_test_scaled = scaler_labels.transform(Y_test)


    X_train_scaled = X_train_scaled.reshape(week, 1, 80)
    Y_train_scaled = Y_train_scaled.reshape(week, 1)

    X_test_scaled = X_test_scaled.reshape(1, 1, 80)
    Y_test_scaled = Y_test_scaled.reshape(1, 1)

    # create and fit the LSTM network
    model = Sequential()
    model.add(Input(shape=(X_train_scaled.shape[1], X_train_scaled.shape[2])))
    model.add(SimpleRNN(lstm_para, activation='relu'))
    model.add(Dropout(0.7))
    model.add(Dense(64, activation='relu'))
    model.add(Dropout(0.7))
    model.add(Dense(32, activation= 'relu'))
    model.add(Dropout(0.7))
    model.add(Dense(1, activation= 'sigmoid'))
    model.compile(loss='mean_squared_error', optimizer='adam')
    model.fit(X_train_scaled, Y_train_scaled, epochs=epoch_para, batch_size=1, verbose=2)

    # make predictions
    # trainPredict = model.predict(X_train_scaled[0].reshape(1,1,80))
    trainPredict = model.predict(X_train_scaled)
    testPredict = model.predict(X_test_scaled)

    # print("Train predictions shape:", trainPredict.shape)

    # invert predictions
    trainPredict = scaler_labels.inverse_transform(trainPredict)
    testPredict = scaler_labels.inverse_transform(testPredict)


      # APEinverse_transform
    # X_score = APE(Y_train, trainPredict)
    Y_score_MAPE, Y_score_MAE = relative_MAE(Y_test, testPredict)
    Y_score_MSE = relative_MSE(Y_test, testPredict)

    return  Y_score_MAPE, Y_score_MAE, Y_score_MSE, Y_test, testPredict



# APE
def relative_MAE(actual, predicted):
    MAE_value = abs((actual[0] - predicted[:, 0]))
    if (actual[0] != 0):
        MAPE_value = MAE_value / actual[0]
    else:
        MAPE_value = None
    return MAPE_value, MAE_value


def relative_MSE(actual, predicted):
    rel_MSE_value = np.square(actual[0] - predicted[:, 0])
    return rel_MSE_value
def run_model(file_path, number_of_weeks, weeks):
    names = getName(file_path)
    data_writer.writerow(
        ["name of drugs", "number of weeks",
         "MAPE_2017", "MAPE_2018", "MAPE_2019", "2016-2019",
         "MAE_2017", "MAE_2018", "MAE_2019", "2016-2019",
         "MSE_2017", "MSE_2018", "MSE_2019", "2016-2019",
         "RMSE_2017", "RMSE_2018", "RMSE_2019", "2016-2019"])
    with open("all" + result, mode='a') as all_results:
        all_results = csv.writer(all_results, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
        all_results.writerow(["Name", "No.", "Actual", "Predicted"])
        for name in names:
            Y_MAPE, Y_MAPE_2017, Y_MAPE_2018, Y_MAPE_2019 = [], [], [], []
            Y_MAE, Y_MAE_2017, Y_MAE_2018, Y_MAE_2019 = [], [], [], []
            Y_MSE, Y_MSE_2017, Y_MSE_2018, Y_MSE_2019 = [], [], [], []

            # dataset_ori = load_data(file_path, name, )
            # train_Nth = (len(dataset_ori) - (number_of_weeks * 2))

            for j in range(1, weeks):

                X_train, X_test = load_data(file_path, name, j)
                Y_score_MAPE, Y_score_MAE, Y_score_MSE, Y_test, testPredict = Simple_RNN(number_of_weeks, X_train, X_test,
                                                                                       lstm, epoch)
                Y_test.astype("float32")
                Y_test = Y_test.item(0)
                testPredict.astype("float32")
                testPredict = round(testPredict.item(0), 3)
                all_results.writerow([name, j, Y_test, testPredict])
                ### MAPE score

                if number_of_weeks == 12:
                    w1 = 3
                    w2 = 56
                    w3 = 108
                else:
                    w1 = 11
                    w2 = 64
                    w3 = 116
                # ### MAPE score
                if Y_score_MAPE != None:
                    if j in range(w1, w2):
                        Y_MAPE_2017.append(Y_score_MAPE)
                    elif j in range(w2, w3):
                        Y_MAPE_2018.append(Y_score_MAPE)
                    elif j >= w3:
                        Y_MAPE_2019.append(Y_score_MAPE)
                    Y_MAPE.append(Y_score_MAPE)
                # # data_writer.writerow([Y_test, testPredict])
                # ### MAE, MSE score
                if j in range(w1, w2):
                    Y_MAE_2017.append(Y_score_MAE)
                    Y_MSE_2017.append(Y_score_MSE)
                    # Y_RMSE_2017.append(Y_score_RMSE)
                elif j in range(w2, w3):
                    Y_MAE_2018.append(Y_score_MAE)
                    Y_MSE_2018.append(Y_score_MSE)
                #     # Y_RMSE_2018.append(Y_score_RMSE)
                elif j >= w3:
                    Y_MAE_2019.append(Y_score_MAE)
                    Y_MSE_2019.append(Y_score_MSE)
                #     # Y_RMSE_2019.append(Y_score_RMSE)

                Y_MAE.append(Y_score_MAE)
                Y_MSE.append(Y_score_MSE)

            ### MAPE for each year
            MAPE_2017 = (sum(Y_MAPE_2017) / len(Y_MAPE_2017)) * 100
            MAPE_2018 = (sum(Y_MAPE_2018) / len(Y_MAPE_2018)) * 100
            MAPE_2019 = (sum(Y_MAPE_2019) / len(Y_MAPE_2019)) * 100
            MAPE_3years = (sum(Y_MAPE) / len(Y_MAPE)) * 100
            ### MAE for each year
            MAE_2017 = (sum(Y_MAE_2017) / len(Y_MAE_2017))
            MAE_2018 = (sum(Y_MAE_2018) / len(Y_MAE_2018))
            MAE_2019 = (sum(Y_MAE_2019) / len(Y_MAE_2019))
            MAE_3years = (sum(Y_MAE) / len(Y_MAE))
            ### MSE for each year
            MSE_2017 = (sum(Y_MSE_2017) / len(Y_MSE_2017))
            MSE_2018 = (sum(Y_MSE_2018) / len(Y_MSE_2018))
            MSE_2019 = (sum(Y_MSE_2019) / len(Y_MSE_2019))
            MSE_3years = (sum(Y_MSE) / len(Y_MSE))
            ### RMSE for each year
            RMSE_2017 = np.sqrt(MSE_2017)
            RMSE_2018 = np.sqrt(MSE_2018)
            RMSE_2019 = np.sqrt(MSE_2019)
            RMSE_3years = np.sqrt(MSE_3years)

            data_writer.writerow(
                [name, number_of_weeks, "%.2f" % MAPE_2017, "%.2f" % MAPE_2018, "%.2f" % MAPE_2019,
                 "%.2f" % MAPE_3years, "%.2f" % MAE_2017, "%.2f" % MAE_2018, "%.2f" % MAE_2019,
                 "%.2f" % MAE_3years, "%.2f" % MSE_2017, "%.2f" % MSE_2018, "%.2f" % MSE_2019,
                 "%.2f" % MSE_3years, "%.2f" % RMSE_2017, "%.2f" % RMSE_2018, "%.2f" % RMSE_2019,
                 "%.2f" % RMSE_3years])
            with open("temp" + result, mode='a') as TempFile:
                TempFile = csv.writer(TempFile, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
                TempFile.writerow(
                    [name, number_of_weeks, "%.2f" % MAPE_2017, "%.2f" % MAPE_2018, "%.2f" % MAPE_2019,
                     "%.2f" % MAPE_3years, "%.2f" % MAE_2017, "%.2f" % MAE_2018, "%.2f" % MAE_2019,
                     "%.2f" % MAE_3years, "%.2f" % MSE_2017, "%.2f" % MSE_2018, "%.2f" % MSE_2019,
                     "%.2f" % MSE_3years, "%.2f" % RMSE_2017, "%.2f" % RMSE_2018, "%.2f" % RMSE_2019,
                     "%.2f" % RMSE_3years])

lstm = 64
epoch = 30
rand = randint(1, 100)
# write to file
nameofresult = "SimpleRNN_NonSD_4W_64_30_Nov3_" + str(rand)
result = nameofresult + ".csv"
file = open(result, "w")
with open(result, mode='a') as data_run:
    data_writer = csv.writer(data_run, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
    start_date = date.today()
    now = datetime.now()
    start_time = now.strftime("%H:%M:%S")
    data_writer.writerow([start_date, start_time, nameofresult])

    # Start
    files = [n for n in fnmatch.filter(os.listdir(path), "*")]
    for i in files:
        file_path = path + "\\" + i
        if i == "4Weeks":
            print("No RUN")
            # break
            run_model(file_path, 4, weeks=154)
        # elif i == "12Weeks":
            # run_model(file_path, 12, weeks=146)
#