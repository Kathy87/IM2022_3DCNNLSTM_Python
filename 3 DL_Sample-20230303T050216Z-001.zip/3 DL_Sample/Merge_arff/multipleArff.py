

import re
import os

import fnmatch

path = "D:\Kathy2021\Data\FULL\\4Weeks"
path_des = "D:\Kathy2021\Data\ForTest\Merged\\4Weeks\\"


def getName(path):
    files = [n for n in fnmatch.filter(os.listdir(path), "*.arff")]
    names = []
    for filename in files:
        x = re.findall("[A-Z0-9]+", filename)
        names.append(x[0]+"_")
    names = list(dict.fromkeys(names))
    return names
def name_file(path1, name1):

    pattern = name1 + "*"
    files = [n for n in fnmatch.filter(os.listdir(path1), pattern)]
    trainfile = []
    for train in files:
        for i in range(1, 154):
            dt_train = "train_" + str(i) + ".arff"
            dt_test = "test_" + str(i) + ".arff"
            x = re.findall("[A-Z0-9a-z-0-9]+", train)
            if dt_train in train:
                # a = []
                # x = re.findall("[A-Z0-9a-z-0-9]+", train)
                trainfile.append( x[0]+"_" + x[1]+"_"+x[2]+"_"+x[3])
            elif dt_test in train:
                if("test_153" in dt_test):
                    trainfile.append( x[0]+"_" + x[1]+"_"+x[2]+"_"+x[3])
                    print("Test File: ", dt_test)
                    break
                else:
                    print("Test File No ADDED", dt_test)
    print("Trainfileeeeeeeeeeeee", trainfile)
    return trainfile

def attributeList(file_names):
    attributeslist = []

    for name in file_names:
        with open(path +"\\{}.arff".format(name)) as out:
            attributes = out.readlines()[0:83]  # The attributes in files are from lines 0-82
            for i in attributes:
                attributeslist.append(i)
    return attributeslist

def allIndividualAttributes(attributes_list, name):
    all_individual_attributes = []

    for i in attributes_list:
        if i not in all_individual_attributes:
            all_individual_attributes.append(i)  # All individual attributes

    for i in all_individual_attributes:
        if "@relation" in i:
            all_individual_attributes.remove(i)
    all_individual_attributes.insert(0, "@relation " + str(name) + "\n")
    return all_individual_attributes

def dataList(trainfile):
    data_list = []
    y = []
    print("data list",trainfile)

    for name  in trainfile:
        with open(path + "\\"+"{}.arff".format(name)) as out:
            a = re.findall("[A-Z0-9a-z-0-9]+", name)
            trainNumber = a[2]+"_"+ a[3]
            testNumber = a[2]+"_"+ a[3]
            if (trainNumber == "train_1"):
                data = out.readlines()[85:]  # The data in files are from line. Copy all if data get from train_1
            elif(testNumber == "test_153"):
                data = out.readlines()[85:]#//train to from 88, and test from 85

                # data = list(data)
            else:
                data = out.readlines()[88:]#//train to from 88, and test from 85
            for i in data:
                if(testNumber=="test_153"):
                    data_list.append(i)
                    data_list.append(i)
                else:
                    data_list.append(i)
    replace_id = []
    for i in data_list:
        a = i.split(",")
        replace_id.append(a)
    return replace_id


def finalDataList(replace_id):
    final_data_list = []
    counter = 0
    current_last_value = 0
    b = 0
    for j in replace_id:
        a1 = replace_id[counter][80]
        # a1 =a1[0]#value === 3
        if (counter >0):

            current_last_value = b
            print ("A111111111111111", b[0])
            print("currentttttttttttt", current_last_value)
            del j[80]
            j.insert(80, current_last_value)
        counter += 1
        concat = ','.join(map(str, j))
        final_data_list.append(concat)
        b = a1
    return final_data_list

names = getName(path)
count = 0
for name in names:
    count += 1

    with open(path_des + name + str(count) + ".arff", "w") as out:  # Write a final combined file
        trainfile = name_file(path, name)
        replace_id = dataList(trainfile)
        final_data_list = finalDataList(replace_id)
        attributes_list = attributeList(trainfile)
        all_individual_attributes = allIndividualAttributes(attributes_list, name)
        for i in all_individual_attributes:
            out.write(i)
        out.write('\n@data\n')
        for j in final_data_list:
            out.write(j)
